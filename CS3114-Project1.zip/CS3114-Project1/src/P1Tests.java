import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ BSTNodeTest.class, RectDataTest.class, RectKeyTest.class, 
                BSTTest.class, Rectangle1Test.class, BSTRectangleTest.class})
public class P1Tests {

}
